package com.example.projectthree_weightapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class Database_User extends SQLiteOpenHelper {


    // Source: Database https://gist.github.com/qndev/5484c6e3c748956d8784bc7d8cf4f811
    // Created the Strings for storing user specific information in the user database

    public static final String USER_TABLE = "USER_TABLE";
    public static final String COLUMN_USER_PASSWORD = "USER_PASSWORD";
    public static final String COLUMN_USER_GOAL_WEIGHT = "USER_GOAL_WEIGHT";
    public static final String COLUMN_USER_PHONE_NUMBER = "USER_PHONE_NUMBER";
    public static final String COLUMN_USER_SMS_ENABLED = "USER_SMS_ENABLED";
    public static final String COLUMN_USERNAME = "COLUMN_USERNAME";
    public static final String COLUMN_ID = "ID";

    // Source: SQLiteOpenHelper https://developer.android.com/reference/android/database/sqlite/SQLiteOpenHelper.html
    // Used a helper object for managing the user database

    public Database_User(@Nullable Context context) {
        super(context, "user.db", null, 1);
    }

    // Source: Autoincrement https://www.topcoder.com/thrive/articles/sqlite-database-in-android
    // Database is created, autoincremnation is implemented so a unique number is assigned to each database entry

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + USER_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_USER_PASSWORD + " TEXT, " + COLUMN_USER_GOAL_WEIGHT + " INTEGER, " + COLUMN_USER_PHONE_NUMBER + " TEXT, " + COLUMN_USER_SMS_ENABLED + " BOOL)";
        db.execSQL(createTableStatement);
    }

    // Source: onUpgrade https://stackoverflow.com/questions/7173896/onupgrade-database-oldversion-newversion
    // Needed a onUpgrade method to properly use SQLiteOpenHelper but wasn't sure what the old and new database version numbers were
    // so this method is unfortunately just a placeholder to keep the program functional

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    // addOne method used to create new users, username and password are provided by the user, but goal weight, phone number,
    // and sms notification are set to a default setting

    public boolean addOne(User_Contents userInfo) {

        // Source: DBHandler Updating https://www.geeksforgeeks.org/how-to-update-data-to-sqlite-database-in-android/#

        // Used a method to call the editable user database

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        // Outlined how provided values are assigned to database fields

        cv.put(COLUMN_USERNAME, userInfo.getUserName());
        cv.put(COLUMN_USER_PASSWORD, userInfo.getPassword());
        cv.put(COLUMN_USER_GOAL_WEIGHT, 0);
        cv.put(COLUMN_USER_PHONE_NUMBER, "");
        cv.put(COLUMN_USER_SMS_ENABLED,0);

        // Source: Storing Values and Empty Values https://stackoverflow.com/questions/50709756/sqlite-store-an-empty-value-in-a-column-type-of-long
        // Used insert method for putting values in database, skipping null fields that need data provided later

        long insert = db.insert(USER_TABLE, null, cv);
        if (insert == -1) {
            return false;
        }
        else{
            return true;
        }
    }

    // Source: Cursor https://stackoverflow.com/questions/49977753/android-getting-string-from-cursor-following-a-raw-query-in-sqlite
    // Source: Inserting data https://stackoverflow.com/questions/60807272/inserting-data-into-sqlite-databases-in-android-studio
    // Updates user's goal weight in database, using a cursor to query each field to find the appropriate position for it
    public boolean updateGoalWeight(String userName, int goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + userName + "'";
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();
        String password = cursor.getString(2);
        String phoneNumber = cursor.getString(4);
        int smsPerms = cursor.getInt(5);
        int idINT = cursor.getInt(0);
        String id = String.valueOf(idINT);
        cv.put(COLUMN_USERNAME, userName);
        cv.put(COLUMN_USER_PASSWORD, password);
        cv.put(COLUMN_USER_GOAL_WEIGHT, goalWeight);
        cv.put(COLUMN_USER_PHONE_NUMBER, phoneNumber);
        cv.put(COLUMN_USER_SMS_ENABLED, smsPerms);
        int success =  db.update(USER_TABLE, cv, "ID=?", new String[] {id});
        cursor.close();
        db.close();
        if (success == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    //  Updates user's phone number in database, using a cursor to query each field to find the appropriate position for it
    public boolean updatePhoneNumber(String username, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();
        String password = cursor.getString(2);
        int goalWeight = cursor.getInt(3);
        int smsPerms = cursor.getInt(5);
        int idINT = cursor.getInt(0);
        String id = String.valueOf(idINT);
        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_USER_PASSWORD, password);
        cv.put(COLUMN_USER_GOAL_WEIGHT, goalWeight);
        cv.put(COLUMN_USER_PHONE_NUMBER, phoneNumber);
        cv.put(COLUMN_USER_SMS_ENABLED, smsPerms);
        //db.insert(USER_TABLE, null, cv);
        int success =  db.update(USER_TABLE, cv, "ID=?", new String[] {id});
        cursor.close();
        db.close();
        if (success == 1) {
            return true;
        }
        else {
            return false;
        }
    }



    // Updates user's sms permissions in database, using a cursor to query each field to find the appropriate position for it
    public boolean updateSmsPerms(String username, int smsPerms) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();
        int goalWeight = cursor.getInt(3);
        String phoneNumber = cursor.getString(4);
        String password = cursor.getString(2);
        int idINT = cursor.getInt(0);
        String id = String.valueOf(idINT);
        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_USER_PASSWORD, password);
        cv.put(COLUMN_USER_GOAL_WEIGHT, goalWeight);
        cv.put(COLUMN_USER_PHONE_NUMBER, phoneNumber);
        cv.put(COLUMN_USER_SMS_ENABLED, smsPerms);
        //db.insert(USER_TABLE, null, cv);
        int success =  db.update(USER_TABLE, cv, "ID=?", new String[] {id});
        cursor.close();
        db.close();
        if (success == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    // Source: getReadable https://stackoverflow.com/questions/13284652/android-sqlite-getreadabledatabase
    // Retrieve's user's sms permissions
    public int getSmsPerms(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();
        int smsPerms = cursor.getInt(5);
        return smsPerms;
    }

    // Retrieve's user's phone number
    public String getPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();
        String phoneNumber = cursor.getString(4);
        return phoneNumber;
    }


    // Retrieves user's goal weight
    public int getUserGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();
        int goalWeight = cursor.getInt(3);
        cursor.close();
        db.close();
        return goalWeight;
    }

    // Source: Query List https://stackoverflow.com/questions/4373263/android-sqlite-rawquery-returns-only-first-record
    // Query user list to find specific username
    public List<String> findUser(String username) {
        List<String> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) {
            // loop through the cursor and return the username and password.
            do {
                String password = cursor.getString(2);
                returnList.add(username);
                returnList.add(password);
            } while (cursor.moveToNext());
        }
        // Close cursor and database
        cursor.close();
        db.close();
        return returnList;
    }

    // Query user list to check username
    public boolean checkUsername(String username) {
        String queryString = "SELECT * FROM " + USER_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);
        // if username exists?
        return cursor.moveToFirst();
    }
}
