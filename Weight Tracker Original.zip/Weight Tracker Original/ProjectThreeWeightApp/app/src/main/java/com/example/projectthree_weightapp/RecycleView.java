package com.example.projectthree_weightapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecycleView extends RecyclerView.Adapter<RecycleView.MyViewHolder> {

    // Initializaes list for Weight_Data
    List<Weight_Data> weightList;
    Context context;

    // Source: Adapter for RecycleView https://stackoverflow.com/questions/38488360/context-error-in-adapter-for-recyclerview
    // Constructor for RecycleView created for Weight_Data list
    public RecycleView(List<Weight_Data> weightList, Context context) {
        this.weightList = weightList;
        this.context = context;
    }

    // view holder identifies the one line layout (xml layout file) and inflater transforms the spacing to match parent object
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.one_line_weight, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    // Source: ViewHolders https://stackoverflow.com/questions/76094678/viewholder-views-must-not-be-attached-when-created-inflator-error
    // ViewHolder made to bind date to their respective columns

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.hDate.setText(weightList.get(position).getDate());
        holder.hWeight.setText(String.valueOf(weightList.get(position).getWeight()));
        holder.hDiff.setText(String.valueOf(weightList.get(position).getDifference()));

    }

    // Size of weightList is returned
    @Override
    public int getItemCount() {
        return weightList.size();
    }

    // subclass for view holder used to bind objects to corresponding layout items
    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView hDate;
        TextView hWeight;
        TextView hDiff;


        //MyViewHolder outlined variables to layout settings
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            hDate = itemView.findViewById(R.id.hDate);
            hWeight = itemView.findViewById(R.id.hWeight);
            hDiff = itemView.findViewById(R.id.hDiff);

        }
    }
}
