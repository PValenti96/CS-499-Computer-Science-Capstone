package com.example.projectthree_weightapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class Database_User_Weight extends SQLiteOpenHelper {


    // Source: Database https://gist.github.com/qndev/5484c6e3c748956d8784bc7d8cf4f811
    // Created the Strings for storing user weight information in the user database

    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String COLUMN_ID = "COLUMN_ID";
    public static final String COLUMN_USERNAME = "COLUMN_USERNAME";
    public static final String COLUMN_DATE = "COLUMN_DATE";
    public static final String COLUMN_WEIGHT = "COLUMN_WEIGHT";
    public static final String COLUMN_DELTA = "COLUMN_DELTA";
    public static final String COLUMN_CATEGORY = "COLUMN_CATEGORY";

    // Source: SQLiteOpenHelper https://developer.android.com/reference/android/database/sqlite/SQLiteOpenHelper.html
    // Used a helper object for managing the user weight database

    public Database_User_Weight(@Nullable Context context) {
        super(context, "weight.db", null, 1);
    }

    // Source: Autoincrement https://www.topcoder.com/thrive/articles/sqlite-database-in-android
    // Database is created, autoincrement is implemented so a unique number is assigned to each database entry

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + WEIGHT_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_DATE + " TEXT, " + COLUMN_WEIGHT + " INTEGER, " + COLUMN_DELTA + " INTEGER, " + COLUMN_CATEGORY + " TEXT)";
        db.execSQL(createTableStatement);
    }

    // Source: onUpgrade https://stackoverflow.com/questions/7173896/onupgrade-database-oldversion-newversion
    // Needed a onUpgrade method to properly use SQLiteOpenHelper but wasn't sure what the old and new database version numbers were
    // so this method is unfortunately just a placeholder to keep the program functional

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // Source: Adding data https://stackoverflow.com/questions/60807272/inserting-data-into-sqlite-databases-in-android-studio
    // Method to increase number of rows by 1
    public boolean increaseOne(Weight_Data weightData, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        // assign content values based on getter functions

        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_DATE, weightData.getDate());
        cv.put(COLUMN_WEIGHT, weightData.getWeight());
        cv.put(COLUMN_DELTA, weightData.getDifference());

        // Used long insert so data can be added to table in reasonable time
        long insert = db.insert(WEIGHT_TABLE, null, cv);
        db.close();
        return insert != -1;
    }

    // Source: Delete Row https://stackoverflow.com/questions/7510219/deleting-row-in-sqlite-in-android
    // Method for deleting row of data
    public boolean deleteOne(String username, String date) {

        SQLiteDatabase db= this.getWritableDatabase();
        int success = db.delete(WEIGHT_TABLE, "COLUMN_USERNAME = ? and COLUMN_DATE =?", new String[]{username, date});
        db.close();
        if (success == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    public boolean updateUserWeight(String username, String date, int weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_DATE + " = ?", new String[]{username, date});
        // cursor moves through database and returns based on finding the right user
        if (cursor.moveToFirst()) {

            // Source: Retrieving column value from cursor https://github.com/SimonVT/schematic/issues/43
            // Returns string value based off of using a cursor to find COLUMN_ID as an int
            int id_int = cursor.getInt(0);
            String id = String.valueOf(id_int);

            // calculate difference between current weight and goal
            int oldCalc = cursor.getInt(4);
            int oldWeight = cursor.getInt(3);
            int goalWeight = oldWeight + oldCalc;
            int new_Weight = goalWeight - weight;


            // create content values object for update method
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_USERNAME, username);
            cv.put(COLUMN_DATE, date);
            cv.put(COLUMN_WEIGHT, weight);
            cv.put(COLUMN_DELTA, new_Weight);


            db.update(WEIGHT_TABLE, cv, "COLUMN_ID=?", new String[] {id});
            cursor.close();
            db.close();
            return true;
        }
        else {
            cursor.close();
            db.close();
            return false;
        }
    }

    // Returns weight list for given username
    public List<Weight_Data> getUserWeights(String username) {
        List<Weight_Data> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        // uses cursor to find matching username
        if (cursor.moveToFirst()) {


            // Loops through cursor to display all appropriate weight info in columns
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                String date = cursor.getString(2);
                int weight = cursor.getInt(3);
                int weight_diff = cursor.getInt(4);



                // Add mew weight from "New_Weight" entry into user wiehg list
                Weight_Data newWeight = new Weight_Data(id, name, date, weight,weight_diff);
                returnList.add(newWeight);
            }
            while (cursor.moveToNext());
        }
        else {
            Log.d("Error", "Unable to add weight");
        }
        // End cursors and close database, return weight list
        cursor.close();
        db.close();
        return returnList;
    }

    // Updates weight difference (calculation between current weight and goal weight)
    public boolean updateWeightDiff(String username, int goalWeight) {
        int new_Weight;
        String queryString = "SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_USERNAME + " = '" + username + "'";
        SQLiteDatabase db = this.getWritableDatabase();

        // Again users cursor to find correct username
        Cursor cursor = db.rawQuery(queryString, null);
        cursor.moveToFirst();

        // Returns string value based off of using a cursor to find COLUMN_ID as an int
        do {
            int idINT = cursor.getInt(0);
            String id = String.valueOf(idINT);
            String date = cursor.getString(2);
            int currWeight = cursor.getInt(3);

            // Calculates weight difference and assign it to Column Delta
            new_Weight = goalWeight - currWeight;
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_USERNAME, username);
            cv.put(COLUMN_DATE, date);
            cv.put(COLUMN_WEIGHT, currWeight);
            cv.put(COLUMN_DELTA, new_Weight);
            db.update(WEIGHT_TABLE, cv, "COLUMN_ID=?", new String[] {id});
        } while (cursor.moveToNext());

        // End cursors and close database, return weight list
        cursor.close();
        db.close();
        return true;
    }

    // Checks if set date already as a weight entry
    public boolean findDate(String username, String date) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Uses cursors and string query to find correct weight table, username, and date
        Cursor cursor = db.rawQuery("SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_DATE + " = ?", new String[]{username, date});

        // if cursor movesToFirst is successful, then date was found
        if (cursor.moveToFirst()) {
            cursor.close();
            db.close();
            return true;
        }
        else {
            cursor.close();
            db.close();
            return false;
        }

        // Regardless of success or not cursor and database are closed after
    }
}