package com.example.projectthree_weightapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;



public class Delete_Weight extends AppCompatActivity {

    //Source DatePickerDialog https://developer.android.com/reference/android/app/DatePickerDialog
    // Initialized variables and DatePickerDialog for selecting which date weigh needs to be removed

    Button dateSelector, yDelete, nDelete;
    private DatePickerDialog datePickerDialog;
    String username;

    // onCreate method called when activity is started.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delete_weight_activity);


        // Date Picker is started
        mDatePicker();
        dateSelector = findViewById(R.id.dateDeleteProcess);

        // Today's date is set
        dateSelector.setText(getTodaysDate());

        // Surce getIntent().getExtras
        //get username and vakyes stored in bundle for user
        Bundle extras = getIntent().getExtras();

        //The key argument here must match that used in the other activity
        assert extras != null;
        username = extras.getString("key");

        // Bind yes and not to delete to variables for user choice
        nDelete = findViewById(R.id.nDelete);
        yDelete = findViewById(R.id.yDelete);

        // Button method for click to cancel deletion, makes sure to check intent of username
        nDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Delete_Weight.this, Weight_Data.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // // Button method for click to successfully delete based off date
        yDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = dateSelector.getText().toString();
                Database_User_Weight databaseUserWeight = new Database_User_Weight(Delete_Weight.this);
                boolean success = databaseUserWeight.deleteOne(username, date);

                // Source: Toast Text https://stackoverflow.com/questions/12214335/error-while-trying-to-create-toast-maketext
                // https://developer.android.com/reference/android/widget/Toast?hl=en
                // Used Toast to signal operation successful or not successful
                if (success) {
                    Toast.makeText(Delete_Weight.this, "Weight removed.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(Delete_Weight.this, "Weight could not be removed, please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to to provide today's date as a string
    private String getTodaysDate() {
        Calendar calendar = Calendar.getInstance();

        // Assigned year, month, and day as int value so date can be selected
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        // When month reaches last day it scrolls over in selector
        month = month +1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    // Calls date picker method
    private void mDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            // Users set date pciking each value
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month +1;
                String date = makeDateString(day, month, year);

                //Date is set
                dateSelector.setText(date);
            }
        };
        // Source: Date Dialog https://mathcs.org/java/android/dialogs_menus.html
        // Set's today's date as default
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);



        // Date selector set so future dates cannot be selected for entries
        datePickerDialog = new DatePickerDialog(this, dateSetListener, year,month, day);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
    }

    // Method to return formatted integer dates into String format
    private String makeDateString(int day, int month, int year) {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    // Source: Int Month to Date https://stackoverflow.com/questions/71900023/how-to-pass-value-recycler-onclicklistener-in-an-activity
    // Return string for the month based on month number
    private String getMonthFormat(int month) {
        if (month == 1)
            return "JAN";
        if (month == 2)
            return "FEB";
        if (month == 3)
            return "MAR";
        if (month == 4)
            return "APR";
        if (month == 5)
            return "MAY";
        if (month == 6)
            return "JUN";
        if (month == 7)
            return "JUL";
        if (month == 8)
            return "AUG";
        if (month == 9)
            return "SEP";
        if (month == 10)
            return "OCT";
        if (month == 11)
            return "NOV";
        if (month == 12)
            return "DEC";

        //Default value for failure for selection option
        return "JAN";
    }

    // Method to open date picker
    public void openDatePickerDelete(View view) {
        datePickerDialog.show();
    }
}