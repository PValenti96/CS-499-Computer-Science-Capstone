package com.example.projectthree_weightapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;


public class Login extends AppCompatActivity {

    private EditText eUsername;
    private EditText ePassword;
    private Button bLogin;
    private Button bRegister;
    boolean isValid = false;


    // Logic for setting view to main screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link appropriate variables to login screen buttons
        eUsername = findViewById(R.id.eUsername);
        ePassword = findViewById(R.id.ePassword);
        bLogin = findViewById(R.id.bLogin);
        bRegister = findViewById(R.id.bRegister);

        // Logic for when new user is setup and added to database
        bRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User_Contents userInfo;
                // Try and catch for either making new user or letting user know that the account was not created if useranme/password was blank
                try {
                    userInfo = new User_Contents(-1, eUsername.getText().toString(), ePassword.getText().toString());
                }
                catch (Exception e){
                    Toast.makeText(Login.this, "Error: User was not registered.", Toast.LENGTH_SHORT).show();
                    userInfo = new User_Contents(-1, "Error: Invalid field", "Error: Invalid field");
                }

                // User database is initialized
                Database_User databaseHelperUser = new Database_User(Login.this);
                boolean userExists = databaseHelperUser.checkUsername(eUsername.getText().toString());

                // Checks if attempted suer credentials are already in database or if the attempt to create account has worked
                if (userExists) {
                    Toast.makeText(Login.this, "Username is not unique....please select another.", Toast.LENGTH_SHORT).show();
                }
                else {
                    boolean pass = databaseHelperUser.addOne(userInfo);
                    Toast.makeText(Login.this, "New user account registered = " +pass, Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Method when login button is selected
        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //Puts text from user input into username and password values
                String inputName = eUsername.getText().toString();
                String inputPassword = ePassword.getText().toString();

                // Checks if either username or password field has remained empty at login attempt
                if(inputName.isEmpty()  || inputPassword.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Please input a full username and password to login.", Toast.LENGTH_SHORT).show();
                }else{

                    isValid = vCredentials(inputName, inputPassword);

                    // Error raised if invalid credentials are entered
                    if(!isValid){

                        Toast.makeText(getApplicationContext(), "Unable to login, please input correct username/password.", Toast.LENGTH_SHORT).show();

                    }

                    // Login is successful, intent is checked with matching username
                    else{
                        Toast.makeText(getApplicationContext(), "Login successful.", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(Login.this, Weight_Info.class);
                        intent.putExtra("key", eUsername.getText().toString());
                        startActivity(intent);
                    }

                }
            }
        });
    }
    // Sources: Reading from list to check credentials https://stackoverflow.com/questions/42901082/reading-from-arraylist-to-check-if-it-contains-username-and-password
    // Check to see if username exists and are valid credentials
    private boolean vCredentials(String name, String password) {

        Database_User databaseHelperUser = new Database_User(Login.this);

        // Try and catch used to either verify credentials or raise exception
        try {
            List<String> user = databaseHelperUser.findUser(name);
            if (name.equals(user.get(0)) && password.equals(user.get(1))) {
                return true;
            }
        } catch (Exception e) {
            Toast.makeText(Login.this, "ERROR: User is not in database.", Toast.LENGTH_SHORT).show();
        }
        return false;
    }
}