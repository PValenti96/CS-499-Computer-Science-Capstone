package com.example.projectthree_weightapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


// Main menu for the app
// User can see weight entries
// Add, edit, and delete entries
// Allow user to export entries if wanted
// Allows for logout

public class Weight_Info extends AppCompatActivity {

    // Sets buttons for UI
    Button bLogout, bAddEntry, bSettings, bEditEntry, bDeleteEntry, bExportCsv;
    String username = "";
    Database_User_Weight databaseHelperUserWeight;

    // SAF (Storage Access Framework) launcher set to create CSV file
    private ActivityResultLauncher<Intent> exportCsvLauncher;

    // Parts of RecyclerView
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    // --- CSV date formatting (app format -> ISO 8601 for spreadsheets) ---
    private static final SimpleDateFormat IN_DATE  =
            new SimpleDateFormat("MMM dd yyyy", Locale.US); // e.g., "SEP 18 2025"
    private static final SimpleDateFormat OUT_DATE =
            new SimpleDateFormat("yyyy-MM-dd", Locale.US);  // e.g., "2025-09-18"

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_data_activity);

        // UI is wired for functionality
        bLogout    = findViewById(R.id.bLogout);
        bSettings  = findViewById(R.id.bSettings);
        bAddEntry  = findViewById(R.id.bAddEntry);
        bEditEntry = findViewById(R.id.bEditEntry);
        bDeleteEntry = findViewById(R.id.bDeleteEntry);
        bExportCsv = findViewById(R.id.bExportCsv);


        // Database helper instance set
        databaseHelperUserWeight = new Database_User_Weight(Weight_Info.this);

        // Obtains username (first from intent, then from shared preferences if needed)
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("key")) {
            username = extras.getString("key", "");
        }
        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE).getString("username", "");
        }

        // Activity launcher for SAF to let user choose filename and location for exported CSV file
        exportCsvLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        if (uri != null) writeCsvToUri(uri);
                    } else {
                        Toast.makeText(this, "Export canceled.", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        // User sets name and file location for access later

        bExportCsv.setOnClickListener(v -> {
            if (username == null || username.isEmpty()) {
                Toast.makeText(this, "No user in context.", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/csv");

            // Format for go to default file setup
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
            intent.putExtra(Intent.EXTRA_TITLE, "weights_" + username + "_" + stamp + ".csv");
            exportCsvLauncher.launch(intent);
        });

        // Add new weight
        bAddEntry.setOnClickListener(v -> {
            Intent intent = new Intent(Weight_Info.this, New_Weight.class);
            intent.putExtra("key", username);
            startActivity(intent);
        });

        // Access settings
        bSettings.setOnClickListener(v -> {
            Intent i = new Intent(Weight_Info.this, Settings.class);
            i.putExtra("key", username);
            startActivity(i);
        });

        // Edit existing weight settings
        bEditEntry.setOnClickListener(v -> {
            Intent intent = new Intent(Weight_Info.this, Edit_Weight.class);
            intent.putExtra("key", username);
            startActivity(intent);
        });

        // Delete existing weight entry
        bDeleteEntry.setOnClickListener(v -> {
            Intent intent = new Intent(Weight_Info.this, Delete_Weight.class);
            intent.putExtra("key", username);
            startActivity(intent);
        });

        // Logout and return back to login screen
        bLogout.setOnClickListener(v -> {

            // Optional SMS reminder if wanted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                Database_User databaseHelperUser = new Database_User(Weight_Info.this);
                String phoneNumber = databaseHelperUser.getPhoneNumber(username);
                String SMS = "Hello User! Please login to Weight Check daily and stay active!";
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, SMS, null, null);
                    Toast.makeText(Weight_Info.this, "Message sent successfully", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(Weight_Info.this, "SMS could not be sent", Toast.LENGTH_SHORT).show();
                }
            } else {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);
            }

            // Clears current session and navigate to login screen
            getSharedPreferences("auth", MODE_PRIVATE).edit().remove("username").apply();
            Intent intent = new Intent(Weight_Info.this, Login.class);
            startActivity(intent);
            finishAffinity();
        });

        // Setup for weight list in RecycleView
        recyclerView = findViewById(R.id.rv_weights);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        reloadList();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Re-reads user5name in case the app is accessed from another screen
        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE).getString("username", "");
        }

        // List is reloaded every time weigh5t list screen is brought up
        reloadList();
    }


    // Method for data source being accessed and goal that is cached in adapter
    private void reloadList() {
        if (databaseHelperUserWeight == null) {
            databaseHelperUserWeight = new Database_User_Weight(this);
        }
        mAdapter = new RecycleView(
                databaseHelperUserWeight.getUserWeights(username),
                this,
                username
        );
        recyclerView.setAdapter(mAdapter);
        Toast.makeText(this, "Rows for " + username + ": " +
                databaseHelperUserWeight.getUserWeights(username).size(), Toast.LENGTH_SHORT).show();
    }

    // CSV writer with BOM, CRLF, and ISO dates for accessible spreadsheets
    private void writeCsvToUri(Uri uri) {
        List<Weight_Data> rows = databaseHelperUserWeight.getUserWeights(username);
        if (rows == null || rows.isEmpty()) {
            Toast.makeText(this, "No weights to export.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Build CSV with LF newlines so Google Sheets/Excel import cleanly
        StringBuilder sb = new StringBuilder();
        final String NL = "\n";

        // Header (its own line)
        sb.append("Date,CurrentWeight,DistanceFromGoal").append(NL);

        // Rows
        for (Weight_Data r : rows) {
            String isoDate = toIsoDate(r.getDate()); // "2025-09-18" or original if parse fails
            sb.append(escapeCsv(isoDate)).append(',')
                    .append(r.getWeight()).append(',')
                    .append(r.getDifference())
                    .append(NL);
        }

        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os == null) {
                Toast.makeText(this, "Unable to open file for writing.", Toast.LENGTH_SHORT).show();
                return;
            }
            // Write once, UTF-8, no BOM
            os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            os.flush();
            Toast.makeText(this, "Exported " + rows.size() + " rows.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // Convert "SEP 18 2025" -> "2025-09-18" (fallback to original if parsing fails)
    private String toIsoDate(String appDate) {
        try {
            Date d = IN_DATE.parse(appDate);
            return (d != null) ? OUT_DATE.format(d) : appDate;
        } catch (ParseException e) {
            return appDate;
        }
    }

    // CSV escape rules set
    private static String escapeCsv(String s) {
        if (s == null) return "";
        boolean needsQuotes = s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r");
        String out = s.replace("\"", "\"\"");  // double quotes
        return needsQuotes ? ("\"" + out + "\"") : out;
    }
}
