package com.example.projectthree_weightapp;

public class Weight_Data {
    private int id;
    private String name;
    private String date;
    private int weight;
    private int weightDiff;
    private int goalWeight;

    // constructors for weight data

    // Weight data without a weight difference
    public Weight_Data(int id, String name, String date, int weight) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.weight = weight;
        this.weightDiff = 0;
        this.goalWeight = 0;

    }

    // Default constructor
    public Weight_Data() {
    }

    // Weight data wit a weight difference
    public Weight_Data(int id, String name, String date, int weight, int weightDiff) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.weight = weight;
        this.weightDiff = weightDiff;
        this.goalWeight = 0;

    }

    // toString method used for applying user specific weight data
    @Override
    public String toString() {
        return "WeightModel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", date='" + date + '\'' +
                ", weight=" + weight +
                ", diff=" + weightDiff +
                ", goalWeight=" + goalWeight +
                '}';
    }

    // getters and setters

    public int getDifference() {
        return weightDiff;
    }

    public void setDifference(int weightDiff) {
        this.weightDiff = weightDiff;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }




}
