package com.example.projectthree_weightapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;


public class New_Weight extends AppCompatActivity {

    // Initializes variables and buttons for adding weight records
    EditText eWeight;
    Button bEnter;
    Button bExit;
    String username = "";
    Button bDatePicker;
    private DatePickerDialog datePickerDialog;



    // Logic for adding new weight record

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("key")) {
            username = extras.getString("key", "");
        }
        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE).getString("username", "");
        }

        //Add weight screen accessed
        setContentView(R.layout.add_weight_activity);


        // Date picker is opened
        mDatePicker();
        bDatePicker = findViewById(R.id.bDatePicker);
        bDatePicker.setText(getTodaysDate());


        // assign buttons to variables
        eWeight = findViewById(R.id.eWeight);
        bEnter = findViewById(R.id.bEnter);
        bExit= findViewById(R.id.bExit);



        // Logic for enter weight data
        bEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // --- Diagnostics: show who/what/when we're saving ---
                String weightEntered = eWeight.getText().toString().trim();
                String dateStr = bDatePicker.getText().toString();
                Toast.makeText(New_Weight.this,
                        "DEBUG -> user=" + username + ", date=" + dateStr + ", weight=\"" + weightEntered + "\"",
                        Toast.LENGTH_SHORT).show();

                // Validate input
                if (weightEntered.isEmpty()) {
                    Toast.makeText(New_Weight.this, "ERROR: Please input weight.", Toast.LENGTH_SHORT).show();
                    return;
                }

                int weightVal;
                try {
                    weightVal = Integer.parseInt(weightEntered); // use Double.parseDouble for decimals
                } catch (NumberFormatException nfe) {
                    Toast.makeText(New_Weight.this, "Invalid number.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Build row
                Weight_Data weightData;
                try {
                    weightData = new Weight_Data(-1, username, dateStr, weightVal);
                } catch (Exception e) {
                    Toast.makeText(New_Weight.this, "Weight was not added: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    return;
                }

                // Compute delta vs goal (if any)
                try {
                    Database_User databaseUser = new Database_User(New_Weight.this);
                    int goalWeight = databaseUser.getUserGoalWeight(username);
                    if (goalWeight != 0) {
                        int diff = goalWeight - weightVal;
                        weightData.setDifference(diff);
                    }
                } catch (Exception ex) {
                    Toast.makeText(New_Weight.this, "DEBUG: goal fetch failed: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                }

                // Insert (or block duplicate date)
                Database_User_Weight db = new Database_User_Weight(New_Weight.this);
                boolean dateUsed;
                try {
                    dateUsed = db.findDate(username, dateStr);
                    Toast.makeText(New_Weight.this, "DEBUG -> dateUsed=" + dateUsed, Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {
                    Toast.makeText(New_Weight.this, "DEBUG: findDate error: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                    return;
                }

                if (dateUsed) {
                    Toast.makeText(New_Weight.this, "User already has a weight saved for this date.", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean pass;
                try {
                    pass = db.increaseOne(weightData, username);
                } catch (Exception ex) {
                    Toast.makeText(New_Weight.this, "Insert error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                    return;
                }

                // *** This is the toast you were not seeing previously ***
                Toast.makeText(New_Weight.this, "Saved: " + pass, Toast.LENGTH_SHORT).show();

                // Return to list with username and close this screen so onResume() runs
                Intent intent = new Intent(New_Weight.this, Weight_Info.class);
                intent.putExtra("key", username);
                startActivity(intent);
                finish();
            }
        });

        bExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(New_Weight.this, Weight_Info.class);
                intent.putExtra("key", username);
                startActivity(intent);
                finish();
            }
        });


    }

    // Method to to provide today's date as a string
    private String getTodaysDate() {
        Calendar calendar = Calendar.getInstance();

        // Assigned year, month, and day as int value so date can be selected
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        // When month reaches last day it scrolls over in selector
        month = month +1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    // method called during onCreate to initialize the date picker
    private void mDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month +1;
                String date = makeDateString(day, month, year);
                bDatePicker.setText(date);
            }
        };
        // today's date
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);


        // date picker with max date being today's date
        datePickerDialog = new DatePickerDialog(this, dateSetListener, year,month, day);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
    }

    // input raw date information and outputs date as string
    private String makeDateString(int day, int month, int year) {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    // Source: Int Month to Date https://stackoverflow.com/questions/71900023/how-to-pass-value-recycler-onclicklistener-in-an-activity
    // Return string for the month based on month number
    private String getMonthFormat(int month) {
        if (month == 1)
            return "JAN";
        if (month == 2)
            return "FEB";
        if (month == 3)
            return "MAR";
        if (month == 4)
            return "APR";
        if (month == 5)
            return "MAY";
        if (month == 6)
            return "JUN";
        if (month == 7)
            return "JUL";
        if (month == 8)
            return "AUG";
        if (month == 9)
            return "SEP";
        if (month == 10)
            return "OCT";
        if (month == 11)
            return "NOV";
        if (month == 12)
            return "DEC";

        //Default value for failure for selection option
        return "JAN";
    }

    // Method called to open date select from xml
    public void openDatePicker(View view) {
        datePickerDialog.show();
    }



}