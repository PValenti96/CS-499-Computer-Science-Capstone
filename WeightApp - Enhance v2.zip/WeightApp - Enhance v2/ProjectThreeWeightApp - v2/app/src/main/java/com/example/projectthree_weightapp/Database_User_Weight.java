package com.example.projectthree_weightapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class Database_User_Weight extends SQLiteOpenHelper {


    // Source: Database https://gist.github.com/qndev/5484c6e3c748956d8784bc7d8cf4f811
    // Created the Strings for storing user weight information in the user database

    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String COLUMN_ID = "COLUMN_ID";
    public static final String COLUMN_USERNAME = "COLUMN_USERNAME";
    public static final String COLUMN_DATE = "COLUMN_DATE";
    public static final String COLUMN_WEIGHT = "COLUMN_WEIGHT";
    public static final String COLUMN_DELTA = "COLUMN_DELTA";
    public static final String COLUMN_CATEGORY = "COLUMN_CATEGORY";

    // Sets working database, needs to b adjusted per database schema chnages
    private static final int DB_VERSION = 3;

    public Database_User_Weight(@Nullable Context context) {
        // CHANGE 1 -> DB_VERSION
        super(context, "weight.db", null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement =
                "CREATE TABLE " + WEIGHT_TABLE + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USERNAME + " TEXT, " +
                        COLUMN_DATE + " TEXT, " +
                        COLUMN_WEIGHT + " INTEGER, " +
                        COLUMN_DELTA + " INTEGER, " +
                        COLUMN_CATEGORY + " TEXT)";
        db.execSQL(createTableStatement);
    }


    // Used to drop old table and recreates if database version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + WEIGHT_TABLE);
        onCreate(db);
    }

    // Source: Adding data https://stackoverflow.com/questions/60807272/inserting-data-into-sqlite-databases-in-android-studio
    // Method to increase number of rows by 1
    public boolean increaseOne(Weight_Data weightData, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_DATE, weightData.getDate());
        cv.put(COLUMN_WEIGHT, weightData.getWeight());
        cv.put(COLUMN_DELTA, weightData.getDifference());

        long insertId = -1;
        try {
            insertId = db.insert(WEIGHT_TABLE, null, cv);
        } catch (Exception ex) {
            Log.e("DB_WEIGHT", "insert error", ex);
        } finally {
            db.close();
        }

        // Optional: toast for deep debug; comment out later
        // Toast.makeText(context, "DEBUG insertId=" + insertId, Toast.LENGTH_SHORT).show();

        return insertId != -1;
    }

    // Source: Delete Row https://stackoverflow.com/questions/7510219/deleting-row-in-sqlite-in-android
    // Method for deleting row of data
    public boolean deleteOne(String username, String date) {

        SQLiteDatabase db= this.getWritableDatabase();
        int success = db.delete(WEIGHT_TABLE, "COLUMN_USERNAME = ? and COLUMN_DATE =?", new String[]{username, date});
        db.close();
        if (success == 1) {
            return true;
        }
        else {
            return false;
        }
    }

    // Method to update an specific weight entry per date

    public boolean updateUserWeight(String username, String date, int weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_DATE + " = ?", new String[]{username, date});
        // cursor moves through database and returns based on finding the right user
        if (cursor.moveToFirst()) {

            // Source: Retrieving column value from cursor https://github.com/SimonVT/schematic/issues/43
            // Returns string value based off of using a cursor to find COLUMN_ID as an int
            int id_int = cursor.getInt(0);
            String id = String.valueOf(id_int);

            // calculate difference between current weight and goal
            int oldCalc = cursor.getInt(4);
            int oldWeight = cursor.getInt(3);
            int goalWeight = oldWeight + oldCalc;
            int new_Weight = goalWeight - weight;


            // create content values object for update method
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_USERNAME, username);
            cv.put(COLUMN_DATE, date);
            cv.put(COLUMN_WEIGHT, weight);
            cv.put(COLUMN_DELTA, new_Weight);


            db.update(WEIGHT_TABLE, cv, "COLUMN_ID=?", new String[] {id});
            cursor.close();
            db.close();
            return true;
        }
        else {

            // Occurs if no matching entry is found
            cursor.close();
            db.close();
            return false;
        }
    }


    // Retrieves all weight entries for user based on dates

    public List<Weight_Data> getUserWeights(String username) {
        List<Weight_Data> out = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Stable & secure
        String sql = "SELECT " +
                COLUMN_ID + "," +
                COLUMN_USERNAME + "," +
                COLUMN_DATE + "," +
                COLUMN_WEIGHT + "," +
                COLUMN_DELTA +
                " FROM " + WEIGHT_TABLE +
                " WHERE " + COLUMN_USERNAME + " = ?" +
                " ORDER BY " + COLUMN_DATE + " ASC";




        // Loop through each row and builds necessary Weight Data objects

        try (Cursor c = db.rawQuery(sql, new String[]{ username })) {
            if (!c.moveToFirst()) {
                db.close();
                return out;
            }

            int ixId     = c.getColumnIndexOrThrow(COLUMN_ID);
            int ixUser   = c.getColumnIndexOrThrow(COLUMN_USERNAME);
            int ixDate   = c.getColumnIndexOrThrow(COLUMN_DATE);
            int ixWeight = c.getColumnIndexOrThrow(COLUMN_WEIGHT);
            int ixDelta  = c.getColumnIndexOrThrow(COLUMN_DELTA);

            do {
                int id      = c.getInt(ixId);
                String usr  = c.getString(ixUser);
                String date = c.getString(ixDate);
                int weight  = c.getInt(ixWeight);
                int delta   = c.getInt(ixDelta);

                out.add(new Weight_Data(id, usr, date, weight, delta));
            } while (c.moveToNext());
        }
        db.close();
        return out;
    }



    // Recalculates the weight difference column for all user entries when goal changes
    public int updateWeightDiff(String username, int goalWeight) {
        int updated = 0;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(
                    "SELECT " + COLUMN_ID + ", " + COLUMN_WEIGHT +
                            " FROM " + WEIGHT_TABLE +
                            " WHERE " + COLUMN_USERNAME + " = ?",
                    new String[]{ username });

            if (cursor != null && cursor.moveToFirst()) {
                int ixId = cursor.getColumnIndexOrThrow(COLUMN_ID);
                int ixW  = cursor.getColumnIndexOrThrow(COLUMN_WEIGHT);
                do {
                    int id   = cursor.getInt(ixId);
                    int w    = cursor.getInt(ixW);
                    int dlt  = goalWeight - w;

                    ContentValues cv = new ContentValues();
                    cv.put(COLUMN_DELTA, dlt);
                    updated += db.update(WEIGHT_TABLE, cv, COLUMN_ID + "=?", new String[]{ String.valueOf(id) });
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return updated;
    }

    // Checks if set date already as a weight entry
    public boolean findDate(String username, String date) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Uses cursors and string query to find correct weight table, username, and date
        Cursor cursor = db.rawQuery("SELECT * FROM " + WEIGHT_TABLE + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_DATE + " = ?", new String[]{username, date});

        // if cursor movesToFirst is successful, then date was found
        if (cursor.moveToFirst()) {
            cursor.close();
            db.close();
            return true;
        }
        else {
            cursor.close();
            db.close();
            return false;
        }

        // Regardless of success or not cursor and database are closed after
    }
}