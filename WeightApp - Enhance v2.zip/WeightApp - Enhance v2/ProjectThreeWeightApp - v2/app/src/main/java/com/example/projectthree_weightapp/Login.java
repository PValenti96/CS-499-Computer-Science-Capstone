package com.example.projectthree_weightapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class Login extends AppCompatActivity {


    // Refres to UI setup for each field and button
    private EditText eUsername, ePassword;
    private Button bLogin, bRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Connect UI setup to layout for proper usability

        eUsername = findViewById(R.id.eUsername);
        ePassword = findViewById(R.id.ePassword);
        bLogin    = findViewById(R.id.bLogin);
        bRegister = findViewById(R.id.bRegister);


        // Handles register function (Adds new user in database)

        bRegister.setOnClickListener(v -> {
            String u = eUsername.getText().toString().trim();
            String p = ePassword.getText().toString().trim();

            // Restricts empty fields as potential entries

            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Creates new database object and adds new user

            Database_User db = new Database_User(this);
            boolean ok = db.addUser(u, p);

            // Notifies user of success or fail of registration

            Toast.makeText(this, ok ? "User registered." : "Registration failed.", Toast.LENGTH_SHORT).show();
        });


        // Handles login functionality (lets user login with authorized credentials)

        bLogin.setOnClickListener(v -> {
            String u = eUsername.getText().toString().trim();
            String p = ePassword.getText().toString().trim();


            // Login fails if username/password fields are empty

            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter username & password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Checks whether credentials are correct

            if (checkLocalCredentials(u, p)) {
                getSharedPreferences("auth", MODE_PRIVATE).edit()
                        .putString("username", u)
                        .apply();

                // Brings user to main menu after successful login
                Intent i = new Intent(Login.this, Weight_Info.class);
                i.putExtra("key", u);
                startActivity(i);
                finish();
            } else {

                // Error message shown after failed login
                Toast.makeText(this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
            }
        });
    }


    // Checks if credentials are stored in the database

    private boolean checkLocalCredentials(String username, String password) {
        try {
            Database_User db = new Database_User(this);
            List<String> user = db.findUser(username);

            // Database returns validated username/password

            return user != null && user.size() >= 2
                    && username.equals(user.get(0))
                    && password.equals(user.get(1));
        } catch (Exception e) {
            return false;
        }
    }
}
