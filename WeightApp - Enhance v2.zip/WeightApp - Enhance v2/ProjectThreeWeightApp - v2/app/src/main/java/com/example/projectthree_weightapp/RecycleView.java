package com.example.projectthree_weightapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;


// RecycleView Adapter will setup a list for each entry
// Date + Current Weight + Difference from Goal Weight + Shows Goal Weight
public class RecycleView extends RecyclerView.Adapter<RecycleView.MyViewHolder> {

    private final Context context;
    private final LayoutInflater inflater;
    private final List<Weight_Data> weightList;   // always non-null, lists all weight entries

    // cached values to avoid constant DB queries
    private final String username;
    private final int goalWeight;

    public RecycleView(List<Weight_Data> weightList, Context context, String username) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);       // inflates XML rows into views for app
        this.weightList = (weightList != null) ? new ArrayList<>(weightList) : new ArrayList<>();
        this.username = username;

        // Fetch's user goal weight once adapter is made

        Database_User du = new Database_User(context);
        this.goalWeight = du.getUserGoalWeight(username);
    }

    /**
     * Optional method to refresh data without remaking adapter.
     */
    public void updateData(List<Weight_Data> newList) {
        this.weightList.clear();
        if (newList != null) this.weightList.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // Inflate a single row (one_line_weight.xml)

        View view = inflater.inflate(R.layout.one_line_weight, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        // Grabs data for current row (one_line_weight.xml)
        Weight_Data row = weightList.get(position);

        // Binds data and current set weight
        holder.hDate.setText(row.getDate());
        holder.hWeight.setText(String.valueOf(row.getWeight()));

        // distance from goal (GREEN if on or above, RED if below)
        int delta = row.getDifference(); // goal - current
        holder.hDiff.setText((delta > 0 ? "+" : "") + delta);
        holder.hDiff.setTextColor(delta >= 0
                ? ContextCompat.getColor(context, android.R.color.holo_green_light)
                : ContextCompat.getColor(context, android.R.color.holo_red_light));

        // rightmost column: goal weight
        holder.hGoal.setText(String.valueOf(goalWeight));
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    // SINGLE ViewHolder definition
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView hDate, hWeight, hDiff, hGoal;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            hDate  = itemView.findViewById(R.id.hDate);
            hWeight= itemView.findViewById(R.id.hWeight);
            hDiff  = itemView.findViewById(R.id.hDiff);
            hGoal  = itemView.findViewById(R.id.hGoal);
        }
    }
}
