package com.example.projectthree_weightapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

//Activity for editing database entries
public class Edit_Weight extends AppCompatActivity {

    // Initialized buttons and needed methods
    Button bDatePicker, bMainScreen, bSave;
    EditText editWeight;
    private DatePickerDialog datePickerDialog;
    String username;

    // Logic for method on creating te view for editing the weight of a day
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_weight_activity);


        // DatePicker initialized
        mDatePicker();
        bDatePicker = findViewById(R.id.btn_datePickerEditScreen);
        bDatePicker.setText(getTodaysDate());


        // Link appropriate variables to buttons
        bMainScreen = findViewById(R.id.btn_homeEditScreen);
        editWeight = findViewById(R.id.editWeight);
        bSave = findViewById(R.id.bSave);

        // Retrieves username from intent bundle
        Bundle extras = getIntent().getExtras();


        // Matches key of that username with stored username in database
        username = extras.getString("key");

        // Logic to return user to mains screen
        bMainScreen.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                // Sends user back home by verifying intent with checked key
                Intent intent = new Intent(Edit_Weight.this, Weight_Info.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Logic for saving edits
        bSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                // Check what change user has put in for selected date's weight
                int weight = Integer.parseInt(editWeight.getText().toString());
                String date = bDatePicker.getText().toString();


                // Open database for instance to save new weight for entered edit
                Database_User_Weight databaseHelperUserWeight = new Database_User_Weight(Edit_Weight.this);


                // Checks in with database helper and sends a toast message base on success or failure of operation
                boolean success = databaseHelperUserWeight.updateUserWeight(username, date, weight);
                if (success) {
                    Toast.makeText(Edit_Weight.this, "Weight Updated.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(Edit_Weight.this, "Weight update failed, please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to to provide today's date as a string
    private String getTodaysDate() {
        Calendar calendar = Calendar.getInstance();

        // Assigned year, month, and day as int value so date can be selected
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        // When month reaches last day it scrolls over in selector
        month = month +1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    // Method to open date selector
    private void mDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month +1;
                String date = makeDateString(day, month, year);
                bDatePicker.setText(date);
            }
        };

        // today's date
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);



        // date picker with max date set as today
        datePickerDialog = new DatePickerDialog(this, dateSetListener, year,month, day);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
    }

    // Returns date entry based on month, day, and year selected
    private String makeDateString(int day, int month, int year) {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    // Source: Int Month to Date https://stackoverflow.com/questions/71900023/how-to-pass-value-recycler-onclicklistener-in-an-activity
    // Return string for the month based on month number
    private String getMonthFormat(int month) {
        if (month == 1)
            return "JAN";
        if (month == 2)
            return "FEB";
        if (month == 3)
            return "MAR";
        if (month == 4)
            return "APR";
        if (month == 5)
            return "MAY";
        if (month == 6)
            return "JUN";
        if (month == 7)
            return "JUL";
        if (month == 8)
            return "AUG";
        if (month == 9)
            return "SEP";
        if (month == 10)
            return "OCT";
        if (month == 11)
            return "NOV";
        if (month == 12)
            return "DEC";

        //Default value for failure for selection option
        return "JAN";
    }

    // Method to open date picker
    public void openDatePickerEdit(View view) {
        datePickerDialog.show();
    }
}