package com.example.projectthree_weightapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Class for settings screen
public class Settings extends AppCompatActivity {

    EditText eGoalWeight, ePhoneNumber;
    Switch sSMS;
    Button bSave, bMainScreen;
    Database_User databaseHelperUser;
    String username = "Error";
    private int SMS_PERMISSION_CODE = 1;

    // Logic for opening settings screen and whats displayed
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // bind buttons to needed editable variables
        eGoalWeight = findViewById(R.id.eGoalWeight);
        ePhoneNumber = findViewById(R.id.ePhoneNumber);
        sSMS = findViewById(R.id.sSMS);
        bSave = findViewById(R.id.bSave);
        bMainScreen = findViewById(R.id.bMainScreen);

        //Username is matched with intent
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("key")) {
            username = extras.getString("key", "");
        }


        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE)
                    .getString("username", "");
        }

        // Verifies user's SMS status
        Database_User databaseHelperUser =  new Database_User(Settings.this);
        int smsPerms = databaseHelperUser.getSmsPerms(username);
        sSMS.setChecked(smsPerms == 1);

        // Logic to let user go back to main screen
        bMainScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // verifies user intent one whether they want to return back to main screen
                Intent intent = new Intent(Settings.this, Weight_Data.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Logic to save settings for goal weight, phone number, and SMS permissions
        bSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Saves user setting choices for applying
                String goalWeight = eGoalWeight.getText().toString();
                String phoneNumber = ePhoneNumber.getText().toString();
                boolean smsPerms = sSMS.isChecked();

                // If Goal weight is empty, then new goal weight can be applied
                if (!goalWeight.matches("")) {

                    // Database insnatce created for tracking settings
                    Database_User databaseHelperUser = new Database_User(Settings.this);
                    boolean pass = databaseHelperUser.updateGoalWeight(username, Integer.parseInt(eGoalWeight.getText().toString()));

                    // If statement for toast message letting user know goal weight was applied
                    if (pass){
                        Toast.makeText(Settings.this, "New Goal Weight Set.", Toast.LENGTH_SHORT).show();
                    }
                }
                // Weight difference value, based off of goal weight, is set in database
                if (!goalWeight.matches("")) {


                    // Database instance created
                    Database_User_Weight databaseHelperUserWeight = new Database_User_Weight(Settings.this);
                    boolean pass = databaseHelperUserWeight.updateWeightDiff(username, Integer.parseInt(eGoalWeight.getText().toString()));

                    // If statement with toast messages showing whether difference between current weight and goal was set
                    if (pass){
                        Toast.makeText(Settings.this, "Weight Difference Updated.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(Settings.this, "Weight Difference Update Failed.", Toast.LENGTH_SHORT).show();
                    }
                }
                // Update database with phone number
                if (!phoneNumber.matches("")) {
                    Database_User databaseHelperUser = new Database_User(Settings.this);
                    boolean pass = databaseHelperUser.updatePhoneNumber(username, ePhoneNumber.getText().toString());

                    // If statement with toast messages showing whether phone number was set or not
                    if (pass){
                        Toast.makeText(Settings.this, "Phone number updated successfully.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(Settings.this, "Phone number update failed.", Toast.LENGTH_SHORT).show();
                    }
                }


                // Updates database with whether or not SMS permissions has been granted, and whether the change in settings is applied
                if (smsPerms) {
                    Database_User databaseHelperUser = new Database_User(Settings.this);
                    boolean pass = databaseHelperUser.updateSmsPerms(username, 1);

                    // If statement with toast messages showing whether permission was granted and if not prompt user for permission
                    if (ContextCompat.checkSelfPermission(Settings.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(Settings.this, "Permission already granted.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        requestSMSPermission();
                    }

                    // If statement with toast messages showing whether permission was granted and if not prompt user for permission
                    if (pass){
                        Toast.makeText(Settings.this, "SMS permissions updated successfully.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(Settings.this, "SMS permissions update failed.", Toast.LENGTH_SHORT).show();
                    }
                }

                // If SMS permissions are not set, same scenario for either changing the settings or keep it as is
                if (!smsPerms) {
                    Database_User databaseHelperUser = new Database_User(Settings.this);
                    boolean success = databaseHelperUser.updateSmsPerms(username, 0);

                    // If statement with toast messages showing whether permission was granted and if not prompt user for permission
                    if (success){
                        Toast.makeText(Settings.this, "SMS permissions updated successfully.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(Settings.this, "SMS permissions update failed.", Toast.LENGTH_SHORT).show();
                    }
                }


                // After User settings are set, user can return to previous screen after checking username's intent
                Intent intent = new Intent(Settings.this, Weight_Data.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });
    }

    // Source: SMSPermissions https://stackoverflow.com/questions/39738711/android-shouldshowrequestpermissionrationale-has-a-bug
    // Method for requesting SMS permissions
    private void requestSMSPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {

            // Alert Dialog if permissions is allowed
            new AlertDialog.Builder(this).setTitle("Permission needs to be set").setMessage("Permission needed for app to coomunciate with you").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.requestPermissions(Settings.this, new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
                }

                // Alert Dialog if user say no to allowing permissions
            }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }).create().show();
        }
        else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }
    // Source: onRequestPermissions https://stackoverflow.com/questions/32714787/android-m-permissions-onrequestpermissionsresult-not-being-called
    // Set permissions settings in database
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission allowed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();

            }
        }
    }
}