package com.example.projectthree_weightapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;


public class New_Weight extends AppCompatActivity {

    // Initializes variables and buttons for adding weight records
    EditText eWeight;
    Button bEnter;
    Button bExit;
    String username = "";
    Button bDatePicker;
    private DatePickerDialog datePickerDialog;



    // Logic for adding new weight record

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Add weight screen accessed
        setContentView(R.layout.add_weight_activity);


        // Date picker is opened
        mDatePicker();
        bDatePicker = findViewById(R.id.bDatePicker);
        bDatePicker.setText(getTodaysDate());


        // assign buttons to variables
        eWeight = findViewById(R.id.eWeight);
        bEnter = findViewById(R.id.bEnter);
        bExit= findViewById(R.id.bExit);

        //Gets intent from username bundle
        Bundle extras = getIntent().getExtras();


        // Key of username is matched with username being referenced in other activities
        assert extras != null;
        username = extras.getString("key");

        // Logic for enter weight data
        bEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Logic to grab entered data and put it properly into weight database
                Weight_Data weightData;

                // Confirms date was entered and changed to string
                String weightEntered = eWeight.getText().toString();

                // Checks if weight is entered, if not, exception raised
                if (weightEntered.matches("")) {
                    Toast.makeText(New_Weight.this, "ERROR: Please input weight.", Toast.LENGTH_SHORT).show();
                }

                // If unique weight data entered, add it into database
                else if (!weightEntered.matches("")) {

                    // Try and catch used for error checking
                    try {
                        weightData = new Weight_Data(-1, username,bDatePicker.getText().toString(), Integer.parseInt(eWeight.getText().toString()));
                    }
                    catch (Exception e) {
                        Toast.makeText(New_Weight.this, "Weight was not added.", Toast.LENGTH_SHORT).show();
                        weightData = new Weight_Data(-1, "error", "error", 0, 0);
                    }

                    // Goal weight is checked and weight difference is calculated
                    Database_User databaseUser = new Database_User(New_Weight.this);
                    int goalWeight = databaseUser.getUserGoalWeight(username);
                    if (goalWeight !=0) {
                        int weightDiff= goalWeight - Integer.parseInt(eWeight.getText().toString());
                        weightData.setDifference(weightDiff);
                    }

                    // New database instance is created
                    Database_User_Weight database_User_inst = new Database_User_Weight(New_Weight.this);


                    // IF weight is found for corresponding date, then return message, otherwise set weight
                    boolean dateUsed = database_User_inst.findDate(username, bDatePicker.getText().toString());

                    if (dateUsed) {
                        Toast.makeText(New_Weight.this, "User already has a weight saved for this date.", Toast.LENGTH_SHORT).show();
                    }
                    else {

                        // If date was empty of records, add weight
                        Boolean pass = database_User_inst.increaseOne(weightData, username);

                        // Success message passed if operation was good
                        Toast.makeText(New_Weight.this, "Operation Status= " + pass, Toast.LENGTH_SHORT).show();

                        // Return to previous screen, after verifying user intent
                        Intent intent = new Intent(New_Weight.this, Weight_Data.class);
                        intent.putExtra("key", username);
                        startActivity(intent);
                    }
                }

                // Else statement if weight was not entered
                else {

                    // Try and catch for putting in new entry or failing too
                    try {
                        weightData = new Weight_Data(-1,username, bDatePicker.getText().toString(), Integer.parseInt(eWeight.getText().toString()), 0);
                    }
                    catch (Exception e) {
                        Toast.makeText(New_Weight.this, "Entry could not be created.", Toast.LENGTH_SHORT).show();
                        weightData = new Weight_Data(-1, "error", "error", 0, 0);
                    }

                    // weightData is updated with difference between goal and current weight
                    Database_User databaseUser = new Database_User(New_Weight.this);
                    int goalWeight = databaseUser.getUserGoalWeight(username);
                    if (goalWeight !=0) {
                        int weightDiff= goalWeight - Integer.parseInt(eWeight.getText().toString());
                        weightData.setDifference(weightDiff);
                    }

                    // Gets new database instance
                    Database_User_Weight databaseUserWeight = new Database_User_Weight(New_Weight.this);


                    // If weight entry exists returns, true
                    boolean dateExists = databaseUserWeight.findDate(username, bDatePicker.getText().toString());

                    // Checks to see if entered date has already been used or not, passing and failing accordingly
                    if (dateExists) {
                        Toast.makeText(New_Weight.this, "Date already has a weight record.", Toast.LENGTH_SHORT).show();
                    }
                    else {

                        // Date is not used, update made to weight database for user
                        Boolean pass = databaseUserWeight.increaseOne(weightData, username);

                        // Success message
                        Toast.makeText(New_Weight.this, "Operation status = " + pass, Toast.LENGTH_SHORT).show();

                        //Returns to previous screen after checking user intent
                        Intent intent = new Intent(New_Weight.this, Weight_Data.class);
                        intent.putExtra("key", username);
                        startActivity(intent);
                    }
                }
            }
        });

        // Exit button to return to Weight history main screen
        bExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(New_Weight.this, Weight_Info.class);
                startActivity(intent);
            }
        });


    }

    // Method to to provide today's date as a string
    private String getTodaysDate() {
        Calendar calendar = Calendar.getInstance();

        // Assigned year, month, and day as int value so date can be selected
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);

        // When month reaches last day it scrolls over in selector
        month = month +1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    // method called during onCreate to initialize the date picker
    private void mDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month +1;
                String date = makeDateString(day, month, year);
                bDatePicker.setText(date);
            }
        };
        // today's date
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);


        // date picker with max date being today's date
        datePickerDialog = new DatePickerDialog(this, dateSetListener, year,month, day);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
    }

    // input raw date information and outputs date as string
    private String makeDateString(int day, int month, int year) {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    // Source: Int Month to Date https://stackoverflow.com/questions/71900023/how-to-pass-value-recycler-onclicklistener-in-an-activity
    // Return string for the month based on month number
    private String getMonthFormat(int month) {
        if (month == 1)
            return "JAN";
        if (month == 2)
            return "FEB";
        if (month == 3)
            return "MAR";
        if (month == 4)
            return "APR";
        if (month == 5)
            return "MAY";
        if (month == 6)
            return "JUN";
        if (month == 7)
            return "JUL";
        if (month == 8)
            return "AUG";
        if (month == 9)
            return "SEP";
        if (month == 10)
            return "OCT";
        if (month == 11)
            return "NOV";
        if (month == 12)
            return "DEC";

        //Default value for failure for selection option
        return "JAN";
    }

    // Method called to open date select from xml
    public void openDatePicker(View view) {
        datePickerDialog.show();
    }



}