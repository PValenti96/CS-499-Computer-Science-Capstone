package com.example.projectthree_weightapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// Main logic for weight data breakdown
public class Weight_Info extends AppCompatActivity {

    Button bLogout, bAddEntry, bSettings, bEditEntry, bDeleteEntry;
    String username = "";
    Database_User_Weight databaseHelperUserWeight;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    // Initializes activity for main screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_data_activity);

        // Binds buttons and fields to variables
        bLogout = findViewById(R.id.bLogout);
        bSettings = findViewById(R.id.bSettings);
        bAddEntry = findViewById(R.id.bAddEntry);
        bEditEntry = findViewById(R.id.bEditEntry);
        bDeleteEntry = findViewById(R.id.bDeleteEntry);

        // DatabaseHelper used
        databaseHelperUserWeight = new Database_User_Weight(Weight_Info.this);

        // Username is bundled into that user's intent, bought over from Login activity
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("key")) {
            username = extras.getString("key", "");
        }

        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE)
                    .getString("username", "");
        }

        // Add button created, reflecting user's intent
        bAddEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Weight_Info.this, New_Weight.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Logout button logic outlined
        bLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                // SMS notification triggered based off of what suer hs set in settings menu
                if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    Database_User databaseHelperUser = new Database_User(Weight_Info.this);
                    String phoneNumber = databaseHelperUser.getPhoneNumber(username);
                    String SMS = "Hello User! Please login to Weight Check daily and stay active!";

                    // Try and catch for confirming failure or success of SMS notifications
                    try {
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNumber, null, SMS, null, null);
                        Toast.makeText(Weight_Info.this, "Message sent successfully", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(Weight_Info.this, "SMS could not be sent", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);
                }

                // User can retrn back to login page
                Intent intent = new Intent(Weight_Info.this, Login.class);
                startActivity(intent);
            }
        });

        // Open Settings Menu
        bSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Weight_Info.this, Settings.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Open Edit Menu
        bEditEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Weight_Info.this, Edit_Weight.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Open Delete Menu
        bDeleteEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Weight_Info.this, Delete_Weight.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Source: RecyclerView https://stackoverflow.com/questions/28709220/understanding-recyclerview-sethasfixedsize
        // RV and variable set

        //iIdentifies the recycler view
        recyclerView = findViewById(R.id.rv_weights);

        // Source: Layout Manager https://stackoverflow.com/questions/50171647/recyclerview-setlayoutmanager
        // Sets a layout manager for the view
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Sets and adapter to receive data from database
        mAdapter = new RecycleView(databaseHelperUserWeight.getUserWeights(username), Weight_Info.this);
        recyclerView.setAdapter(mAdapter);
    }

}