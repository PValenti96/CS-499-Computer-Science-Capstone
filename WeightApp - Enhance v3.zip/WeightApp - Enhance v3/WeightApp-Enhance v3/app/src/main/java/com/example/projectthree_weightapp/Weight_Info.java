package com.example.projectthree_weightapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


// packages for export CSV functionality

import android.content.ActivityNotFoundException;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.net.Uri;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Date;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// Main logic for weight data breakdown
public class Weight_Info extends AppCompatActivity {

    Button bLogout, bAddEntry, bSettings, bEditEntry, bDeleteEntry;
    String username = "";
    Database_User_Weight databaseHelperUserWeight;

    // CSV functionality
    private Button bExportCsv;

    private ActivityResultLauncher<Intent> exportCsvLauncher;


    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private static final SimpleDateFormat INPUT =
            new SimpleDateFormat("MMM dd yyyy", Locale.US);


    private void openCsv(Uri uri) {
        Intent openIntent = new Intent(Intent.ACTION_VIEW);
        openIntent.setDataAndType(uri, "text/csv");
        openIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            startActivity(Intent.createChooser(openIntent, "Open CSV with"));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this,
                    "No app found to open CSV. Install Google Sheets or Microsoft Excel.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void writeCsvToUri(Uri uri) {
        List<Weight_Data> rows = databaseHelperUserWeight.getUserWeights(username);
        if (rows == null || rows.isEmpty()) {
            Toast.makeText(this, "No weights to export.", Toast.LENGTH_SHORT).show();
            return;
        }

        StringBuilder sb = new StringBuilder(256);
        // Header
        sb.append("Date,CurrentWeight,DistanceFromGoal").append('\n');

        // Data rows
        for (Weight_Data r : rows) {
            sb.append(csv(r.getDate())).append(',')           // Date (escaped)
                    .append(r.getWeight()).append(',')              // Current weight
                    .append(r.getDifference()).append('\n');        // Distance from goal
        }

        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
            if (os == null) {
                Toast.makeText(this, "Unable to open file for writing.", Toast.LENGTH_SHORT).show();
                return;
            }
            os.write(sb.toString().getBytes(StandardCharsets.UTF_8));
            os.flush();
            Toast.makeText(this, "Exported " + rows.size() + " rows.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Escape a value for CSV (commas/quotes/newlines) */
    private static String csv(String s) {
        if (s == null) return "";
        boolean needsQuotes = s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r");
        String out = s.replace("\"", "\"\""); // double any quotes
        return needsQuotes ? "\"" + out + "\"" : out;
    }

    // basic CSV escaper for fields that may contain commas/quotes








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_data_activity);



        // Binds buttons and fields to variables
        bLogout = findViewById(R.id.bLogout);
        bSettings = findViewById(R.id.bSettings);
        bAddEntry = findViewById(R.id.bAddEntry);
        bEditEntry = findViewById(R.id.bEditEntry);
        bDeleteEntry = findViewById(R.id.bDeleteEntry);

        // Database helper
        databaseHelperUserWeight = new Database_User_Weight(Weight_Info.this);

        Button bViewChart = findViewById(R.id.bViewChart);
        bViewChart.setOnClickListener(v -> {
            Intent i = new Intent(Weight_Info.this, Weight_Data_Chart.class);
            i.putExtra("key", username);   // pass current user
            startActivity(i);
        });



        // CSV functionality
        bExportCsv = findViewById(R.id.bExportCsv);

        // register the launcher once
        exportCsvLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        if (uri != null) writeCsvToUri(uri);
                    } else {
                        Toast.makeText(this, "Export canceled.", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        // click -> ask user where to save
        bExportCsv.setOnClickListener(v -> {
            if (username == null || username.isEmpty()) {
                Toast.makeText(this, "No user in context.", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/csv");

            String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date());
            String fileName = "weights_" + username + "_" + stamp + ".csv";
            intent.putExtra(Intent.EXTRA_TITLE, fileName);

            exportCsvLauncher.launch(intent);
        });






        // --- Get username from Intent with a safe fallback to SharedPreferences ---
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("key")) {
            username = extras.getString("key", "");
        }
        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE)
                    .getString("username", "");
        }


        // Add Weight
        bAddEntry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(Weight_Info.this, New_Weight.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Logout
        bLogout.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                // Optional: SMS reminder (policy-restricted on Play Store)
                if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    Database_User databaseHelperUser = new Database_User(Weight_Info.this);
                    String phoneNumber = databaseHelperUser.getPhoneNumber(username);
                    String SMS = "Hello User! Please login to Weight Check daily and stay active!";
                    try {
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNumber, null, SMS, null, null);
                        Toast.makeText(Weight_Info.this, "Message sent successfully", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(Weight_Info.this, "SMS could not be sent", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);
                }

                // Clear saved auth and go to login; finish so Back won't return here
                getSharedPreferences("auth", MODE_PRIVATE).edit()
                        .remove("username")
                        .apply();
                Intent intent = new Intent(Weight_Info.this, Login.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        bSettings.setOnClickListener(v -> {
            Intent i = new Intent(Weight_Info.this, Settings.class);
            i.putExtra("key", username);   // pass current user
            startActivity(i);
        });

        // Edit
        bEditEntry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(Weight_Info.this, Edit_Weight.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // Delete
        bDeleteEntry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                Intent intent = new Intent(Weight_Info.this, Delete_Weight.class);
                intent.putExtra("key", username);
                startActivity(intent);
            }
        });

        // RecyclerView setup
        recyclerView = findViewById(R.id.rv_weights);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // Initial load
        reloadList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE).getString("username", "");
        }
        reloadList();
    }

    private void reloadList() {


        if (databaseHelperUserWeight == null) {
            databaseHelperUserWeight = new Database_User_Weight(this);
        }
        mAdapter = new RecycleView(
                databaseHelperUserWeight.getUserWeights(username),
                this,
                username
        );
        recyclerView.setAdapter(mAdapter);

        Toast.makeText(this,
                "Rows for " + username + ": " + databaseHelperUserWeight.getUserWeights(username).size(),
                Toast.LENGTH_SHORT
        ).show();


        Toast.makeText(this, "Rows for " + username + ": " + databaseHelperUserWeight.getUserWeights(username).size(), Toast.LENGTH_SHORT).show();

    }
}