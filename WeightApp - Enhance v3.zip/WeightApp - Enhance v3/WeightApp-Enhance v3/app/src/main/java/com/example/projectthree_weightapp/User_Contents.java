package com.example.projectthree_weightapp;

public class User_Contents {

    private int id;
    private String username;
    private String password;
    private int goalWeight;
    private String phoneNumber;
    private boolean SMSstate;

    // Constructors for user data

    public User_Contents(int id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.goalWeight = 0;
        this.phoneNumber = null;
        this.SMSstate = false;
    }

    // default constructor
    public User_Contents() {
    }


    // toString method used for applying user data to settings
    @Override
    public String toString() {
        return "UserModel{" +
                "id=" + id +
                ", userName='" + username + '\'' +
                ", password='" + password +
                ", goalWeight=" + goalWeight +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", isSmsEnabled=" + SMSstate +
                '}';
    }

    // getters and setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getUserName() {
        return username;
    }
    public String getPassword() {
        return password;
    }


}
