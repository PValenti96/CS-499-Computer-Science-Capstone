package com.example.projectthree_weightapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Login extends AppCompatActivity {

    Connection con;
    String str;

    private EditText eUsername;
    private EditText ePassword;
    private Button bLogin;
    private Button bRegister;
    boolean isValid = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 🔹 Attempt SQL connection as soon as the app launches
        connectToSqlOnLaunch();

        // Link UI elements
        eUsername = findViewById(R.id.eUsername);
        ePassword = findViewById(R.id.ePassword);
        bLogin = findViewById(R.id.bLogin);
        bRegister = findViewById(R.id.bRegister);

        // Registration button logic
        bRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User_Contents userInfo;

                try {
                    userInfo = new User_Contents(-1, eUsername.getText().toString(), ePassword.getText().toString());
                } catch (Exception e) {
                    Toast.makeText(Login.this, "Error: User was not registered.", Toast.LENGTH_SHORT).show();
                    userInfo = new User_Contents(-1, "Error: Invalid field", "Error: Invalid field");
                }

                ExecutorService executor = Executors.newSingleThreadExecutor();
                executor.execute(() -> {
                    try {
                        ConnectionClass connectionClass = new ConnectionClass();
                        Connection con = connectionClass.CONN();

                        if (con != null) {
                            // Check if user already exists
                            String checkQuery = "SELECT * FROM Users WHERE username = ?";
                            PreparedStatement checkStmt = con.prepareStatement(checkQuery);
                            checkStmt.setString(1, eUsername.getText().toString());
                            ResultSet rs = checkStmt.executeQuery();

                            if (rs.next()) {
                                runOnUiThread(() -> Toast.makeText(Login.this, "Username is not unique. Please choose another.", Toast.LENGTH_SHORT).show());
                            } else {
                                // Insert new user
                                String insertQuery = "INSERT INTO Users (username, password) VALUES (?, ?)";
                                PreparedStatement insertStmt = con.prepareStatement(insertQuery);
                                insertStmt.setString(1, eUsername.getText().toString());
                                insertStmt.setString(2, ePassword.getText().toString());
                                insertStmt.executeUpdate();

                                runOnUiThread(() -> Toast.makeText(Login.this, "User registered successfully.", Toast.LENGTH_SHORT).show());

                                insertStmt.close();
                            }

                            rs.close();
                            checkStmt.close();
                            con.close();
                        } else {
                            runOnUiThread(() -> Toast.makeText(Login.this, "SQL connection failed during registration.", Toast.LENGTH_SHORT).show());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        runOnUiThread(() -> Toast.makeText(Login.this, "Registration error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                    }
                });

                // Old SQL test connection — can be removed or kept
                ConnectionClass connectionClass = new ConnectionClass();
                con = connectionClass.CONN();
                connect();
            }

            public void connect() {
                ExecutorService executorService = Executors.newSingleThreadExecutor();
                executorService.execute(() -> {
                    try {
                        if (con == null) {
                            str = "Error";
                        } else {
                            str = "Connected with SQL server";
                        }
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                    runOnUiThread(() -> {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                        Toast.makeText(Login.this, str, Toast.LENGTH_SHORT).show();
                        TextView txtList = findViewById(R.id.txtmsg);
                        txtList.setText(str);
                    });
                });
            }
        });

        // Login button logic
        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputName = eUsername.getText().toString();
                String inputPassword = ePassword.getText().toString();

                if (inputName.isEmpty() || inputPassword.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please input a full username and password to login.", Toast.LENGTH_SHORT).show();
                } else {
                    ExecutorService executorService = Executors.newSingleThreadExecutor();
                    executorService.execute(() -> {
                        boolean loginSuccess = checkUserFromSqlServer(inputName, inputPassword);

                        runOnUiThread(() -> {
                            if (loginSuccess) {
                                Toast.makeText(getApplicationContext(), "Login successful.", Toast.LENGTH_SHORT).show();

                                // Persist the username so downstream screens can fall back if an Intent extra is missing
                                getSharedPreferences("auth", MODE_PRIVATE)
                                        .edit()
                                        .putString("username", inputName)   // or eUsername.getText().toString()
                                        .apply();

                                Intent intent = new Intent(Login.this, Weight_Info.class);
                                intent.putExtra("key", inputName);
                                startActivity(intent);

                                // Prevent returning to Login when pressing back
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(),
                                        "Unable to login, please input correct username/password.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                    });
                }
            }
        });
    }

    // 🔹 Connect to SQL Server immediately on app launch
    private void connectToSqlOnLaunch() {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            ConnectionClass connectionClass = new ConnectionClass();
            Connection conn = connectionClass.CONN();
            String status;

            if (conn != null) {
                status = "Connected to SQL Server.";
            } else {
                status = "Failed to connect to SQL Server.";
            }

            runOnUiThread(() -> {
                Toast.makeText(Login.this, status, Toast.LENGTH_SHORT).show();
                TextView txtList = findViewById(R.id.txtmsg);
                txtList.setText(status);
            });
        });
    }

    // 🔹 Validate login credentials against SQL Server
    private boolean checkUserFromSqlServer(String username, String password) {
        boolean loginSuccess = false;

        try {
            ConnectionClass connectionClass = new ConnectionClass();
            Connection con = connectionClass.CONN();

            if (con != null) {
                String query = "SELECT * FROM Users WHERE username = ? AND password = ?";
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, username);
                stmt.setString(2, password);

                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    loginSuccess = true;
                }

                rs.close();
                stmt.close();
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
            runOnUiThread(() -> Toast.makeText(Login.this, "SQL Server Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }

        return loginSuccess;
    }

    // 🔹 Old SQLite login check (can be removed if moving fully to SQL Server)
    private boolean vCredentials(String name, String password) {
        Database_User databaseHelperUser = new Database_User(Login.this);

        try {
            List<String> user = databaseHelperUser.findUser(name);
            if (name.equals(user.get(0)) && password.equals(user.get(1))) {
                return true;
            }
        } catch (Exception e) {
            Toast.makeText(Login.this, "ERROR: User is not in database.", Toast.LENGTH_SHORT).show();
        }
        return false;
    }
}