package com.example.projectthree_weightapp;

import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


// Provides a method to establish a connection between the Android app
 // and a remote SQL Server database using the jTDS JDBC driver.
 // This enhancement allows the app to pull
 // and push user data (e.g., weight records) directly from SQL Server
 // instead of relying solely only on local storage.

public class ConnectionClass {


    // JDBC driver class for SQL Server (using jTDS)

    String classes = "net.sourceforge.jtds.jdbc.Driver";


    // Database connection parameters
    protected static String ip = "10.0.2.2";  // free ip address to operate from
    protected static String port = "1433"; // Default port fort SQL server
    protected static String db = "demo"; // Name for database
    protected static String un = "sa"; // Username for database
    protected static String password = "12345"; // Database password


    // Establishes connection to SQL Database and returns the "Connection Object"
    public Connection CONN() {

        // Policy made to temporarily allow network connections that are typically blocked by Android
        // https://developer.android.com/reference/android/os/StrictMode.ThreadPolicy.Builder
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection conn = null;
        try {

            // Loads the JDBC driver class
            // https://www.microfocus.com/documentation/visual-cobol/vc80/EclWin/GUID-529E82D0-F964-4AD2-B948-16B793930F3D.html
            Class.forName(classes);

            // Builds connection per JDTS format
            // https://stackoverflow.com/questions/1862283/create-a-jtds-connection-string
            String conUrl = "jdbc:jtds:sqlserver://" + ip + ":" + port + ";databaseName=" + db + ";user=" + un + ";password=" + password + ";";

            // Attempts connection
            conn = DriverManager.getConnection(conUrl);
        } catch (SQLException | ClassNotFoundException e) {

            // Error logged for connection failure
            Log.e("SQL ERROR", e.getMessage());
            e.printStackTrace();
        }
        return conn;
    }
}
