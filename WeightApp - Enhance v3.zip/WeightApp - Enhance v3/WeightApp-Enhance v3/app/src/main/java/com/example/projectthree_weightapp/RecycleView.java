package com.example.projectthree_weightapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecycleView extends RecyclerView.Adapter<RecycleView.MyViewHolder> {

    private final Context context;
    private final LayoutInflater inflater;
    private final List<Weight_Data> weightList;   // always non-null

    // cache username + goal once
    private final String username;
    private final int goalWeight;

    public RecycleView(List<Weight_Data> weightList, Context context, String username) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);       // <-- initialize inflater
        this.weightList = (weightList != null) ? new ArrayList<>(weightList) : new ArrayList<>();
        this.username = username;

        Database_User du = new Database_User(context);
        this.goalWeight = du.getUserGoalWeight(username);
    }

    /** Optional: refresh data without recreating adapter */
    public void updateData(List<Weight_Data> newList) {
        this.weightList.clear();
        if (newList != null) this.weightList.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.one_line_weight, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Weight_Data row = weightList.get(position);

        holder.hDate.setText(row.getDate());
        holder.hWeight.setText(String.valueOf(row.getWeight()));

        // distance from goal
        int delta = row.getDifference(); // goal - current
        holder.hDiff.setText((delta > 0 ? "+" : "") + delta);
        holder.hDiff.setTextColor(delta >= 0
                ? ContextCompat.getColor(context, android.R.color.holo_green_light)
                : ContextCompat.getColor(context, android.R.color.holo_red_light));

        // rightmost column: goal weight
        holder.hGoal.setText(String.valueOf(goalWeight));
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    // SINGLE ViewHolder definition (remove any duplicates)
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView hDate, hWeight, hDiff, hGoal;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            hDate  = itemView.findViewById(R.id.hDate);
            hWeight= itemView.findViewById(R.id.hWeight);
            hDiff  = itemView.findViewById(R.id.hDiff);
            hGoal  = itemView.findViewById(R.id.hGoal);  // <-- must exist in XML
        }
    }
}
