package com.example.projectthree_weightapp;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

public class Weight_Data_Chart extends AppCompatActivity {


    // Helps setup UI
    private Switch sChartType;
    private Button bBackToList;
    private LineChart lineChart;
    private BarChart barChart;



    // Sets ranges for the charts
    private float minX, maxX;
    private float minWeight, maxWeight;



    private String username = "";
    private int goal = 0;

    // Date set using UTC so the days are not offset by one
    private static final long MILLIS_PER_DAY = 24L * 60L * 60L * 1000L;
    private static final TimeZone UTC = TimeZone.getTimeZone("UTC");


    // sets up date format
    private static final SimpleDateFormat INPUT =
            new SimpleDateFormat("MMM dd yyyy", Locale.US);
    private static final SimpleDateFormat LABEL =
            new SimpleDateFormat("MMM dd", Locale.US);

    static {
        // Force both parsing and label formatting to UTC time setting
        INPUT.setTimeZone(UTC);
        LABEL.setTimeZone(UTC);
    }

    // Parses using "MMM dd yyyy" as UTC midnight
    private static long parseMillisUtc(String s) {
        try {
            java.util.Date d = INPUT.parse(s);
            return (d != null) ? d.getTime() : 0L;
        } catch (ParseException e) {
            return 0L;
        }
    }

    // Convert app date -
    private static int toEpochDayInt(String dateStr) {
        return (int) (parseMillisUtc(dateStr) / MILLIS_PER_DAY);
    }

    // Helps label only on days with data
    private static class TickDayFormatter extends ValueFormatter {
        private static final float EPS = 0.25f; // tolerance in “day” units
        private final Set<Integer> allowedDays;

        TickDayFormatter(Set<Integer> allowedDays) {
            this.allowedDays = allowedDays;
        }

        @Override
        public String getFormattedValue(float value) {

            // Helps format days to the closest value
            int nearest = Math.round(value);
            if (Math.abs(value - nearest) > EPS) return "";      // not close to a whole day
            if (!allowedDays.contains(nearest)) return "";        // day not in our data
            long ms = (long) nearest * MILLIS_PER_DAY;           // UTC midnight for that day
            return LABEL.format(new java.util.Date(ms));
        }
    }

    private final ArrayList<Entry>    lineEntries  = new ArrayList<>();
    private final ArrayList<BarEntry> barEntries   = new ArrayList<>();
    private final Set<Integer>        tickDayInts  = new HashSet<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_data_chart);


        // Wires up UI to screen itself
        sChartType  = findViewById(R.id.sChartType);
        bBackToList = findViewById(R.id.bBackToList);
        lineChart   = findViewById(R.id.lineChart);
        barChart    = findViewById(R.id.barChart);

        // Determines user
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("key")) {
            username = extras.getString("key", "");
        }
        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE).getString("username", "");
        }

        // Determines used data
        Database_User_Weight wdb = new Database_User_Weight(this);
        List<Weight_Data> weights = wdb.getUserWeights(username);
        if (weights == null || weights.isEmpty()) {
            Toast.makeText(this, "No data to chart.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // sort ascending by date
        Collections.sort(weights, (a, b) ->
                Integer.compare(toEpochDayInt(a.getDate()), toEpochDayInt(b.getDate())));

        // build entries & ranges
        lineEntries.clear();
        barEntries.clear();
        tickDayInts.clear();

        int minDay = Integer.MAX_VALUE;
        int maxDay = Integer.MIN_VALUE;
        minWeight = Float.POSITIVE_INFINITY;
        maxWeight = Float.NEGATIVE_INFINITY;

        for (Weight_Data r : weights) {
            int   day = toEpochDayInt(r.getDate()); // X
            float w   = r.getWeight();              // Y

            lineEntries.add(new Entry(day, w));
            barEntries.add(new BarEntry(day, w));

            tickDayInts.add(day);

            if (day < minDay) minDay = day;
            if (day > maxDay) maxDay = day;
            if (w   < minWeight) minWeight = w;
            if (w   > maxWeight) maxWeight = w;
        }
        this.minX = minDay;
        this.maxX = maxDay;

        // goal line is set per user
        Database_User udb = new Database_User(this);
        goal = udb.getUserGoalWeight(username);


        // prints both charts using min and max day per data
        setupLineChart(minDay, maxDay);
        setupBarChart(minDay, maxDay);

        // toggle button is setup
        sChartType.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton btn, boolean isChecked) {
                if (isChecked) {
                    lineChart.setVisibility(View.GONE);
                    barChart.setVisibility(View.VISIBLE);
                    barChart.animateY(500);
                } else {
                    barChart.setVisibility(View.GONE);
                    lineChart.setVisibility(View.VISIBLE);
                    lineChart.animateX(500);
                }
            }
        });

        bBackToList.setOnClickListener(v -> finish());
    }

    // Configures line chart with labeled points

    private void setupLineChart(int axisMinInt, int axisMaxInt) {
        LineDataSet ds = new LineDataSet(lineEntries, "Weight");
        ds.setMode(LineDataSet.Mode.LINEAR);  // exact point-to-point
        ds.setLineWidth(2f);
        ds.setCircleRadius(3.5f);

        ds.setDrawValues(true);                 // show labels on the points
        ds.setValueTextColor(Color.WHITE);      // label color
        ds.setValueTextSize(10f);               // label size

        // show whole-number pounds (e.g., 160), not decimals
        ds.setValueFormatter(new ValueFormatter() {
            @Override public String getPointLabel(Entry e) {
                return String.valueOf(Math.round(e.getY()));
            }
        });

        lineChart.setData(new LineData(ds));

        // X-Axis is set

        XAxis x = lineChart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setTextColor(Color.WHITE);
        x.setDrawLabels(true);

        // Whole-day bounds
        x.setAxisMinimum(axisMinInt - 1f);
        x.setAxisMaximum(axisMaxInt + 1f);

        // One tick per integer day
        x.setGranularity(1f);
        x.setGranularityEnabled(true);
        x.setLabelCount((axisMaxInt - axisMinInt) + 1, false);

        // Show labels only on days we logged
        x.setValueFormatter(new TickDayFormatter(tickDayInts));

        x.setLabelRotationAngle(-35f);
        x.setAvoidFirstLastClipping(false);
        x.setDrawGridLines(true);

        // Y-Axis

        YAxis left = lineChart.getAxisLeft();
        left.setAxisMinimum((float) (Math.floor(minWeight / 5.0) * 5) - 5);
        left.setAxisMaximum((float) (Math.ceil (maxWeight / 5.0) * 5) + 5);
        left.setGranularity(1f);
        lineChart.getAxisRight().setEnabled(false);

        addGoalLine(left);

        Description d = new Description();
        d.setText("");
        lineChart.setDescription(d);
        lineChart.getLegend().setEnabled(true);

        lineChart.setExtraBottomOffset(18f);
        lineChart.invalidate();
    }


    // Configures bar chart with labeled points

    private void setupBarChart(int axisMinInt, int axisMaxInt) {
        BarDataSet bds = new BarDataSet(barEntries, "Weight");
        bds.setDrawValues(true);

        BarData bd = new BarData(bds);
        bd.setBarWidth(0.9f); // ~90% of a day width, centered on tick
        barChart.setData(bd);
        barChart.setFitBars(true);


        // X-Axis is set

        XAxis x = barChart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setTextColor(Color.WHITE);
        x.setDrawLabels(true);

        x.setAxisMinimum(axisMinInt - 1f);
        x.setAxisMaximum(axisMaxInt + 1f);

        x.setGranularity(1f);
        x.setGranularityEnabled(true);
        x.setCenterAxisLabels(false);
        x.setLabelCount((axisMaxInt - axisMinInt) + 1, false);

        x.setValueFormatter(new TickDayFormatter(tickDayInts));
        x.setLabelRotationAngle(-35f);
        x.setAvoidFirstLastClipping(false);
        x.setDrawGridLines(true);


        // Y-Axis

        YAxis left = barChart.getAxisLeft();
        left.setAxisMinimum((float) (Math.floor(minWeight / 5.0) * 5) - 5);
        left.setAxisMaximum((float) (Math.ceil (maxWeight / 5.0) * 5) + 5);
        left.setGranularity(1f);
        barChart.getAxisRight().setEnabled(false);

        addGoalLine(left);

        Description d = new Description();
        d.setText("");
        barChart.setDescription(d);
        barChart.getLegend().setEnabled(true);

        barChart.setExtraBottomOffset(18f);
        barChart.invalidate();
    }

    private void addGoalLine(YAxis axisLeft) {
        axisLeft.removeAllLimitLines();
        if (goal > 0) {
            LimitLine goalLine = new LimitLine(goal, "Goal " + goal);
            goalLine.setLineWidth(1.5f);
            goalLine.setTextSize(10f);
            axisLeft.addLimitLine(goalLine);
        }
    }
}
