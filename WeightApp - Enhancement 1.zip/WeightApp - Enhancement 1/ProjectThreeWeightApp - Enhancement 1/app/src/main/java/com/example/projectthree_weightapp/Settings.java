package com.example.projectthree_weightapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Class for settings screen
public class Settings extends AppCompatActivity {

    EditText eGoalWeight, ePhoneNumber;
    Switch sSMS;
    Button bSave, bMainScreen;
    Database_User databaseHelperUser;
    String username = "Error";
    private int SMS_PERMISSION_CODE = 1;

    // Logic for opening settings screen and whats displayed
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);



        // bind buttons to needed editable variables
        eGoalWeight = findViewById(R.id.eGoalWeight);
        ePhoneNumber = findViewById(R.id.ePhoneNumber);
        sSMS = findViewById(R.id.sSMS);
        bSave = findViewById(R.id.bSave);
        bMainScreen = findViewById(R.id.bMainScreen);

        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.containsKey("key")) {
            username = extras.getString("key", "");
        }
        if (username == null || username.isEmpty()) {
            username = getSharedPreferences("auth", MODE_PRIVATE).getString("username", "");
        }
        if (username == null || username.isEmpty()) {
            Toast.makeText(this, "No user in context. Please log in again.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Settings.this, Login.class));
            finish();
            return;
        }

// --- Safely read SMS perms; default to 0 on any issue ---
        int smsPerms = 0;
        try {
            Database_User databaseHelperUser = new Database_User(Settings.this);
            smsPerms = databaseHelperUser.getSmsPerms(username);
        } catch (Exception e) {
            // optional: Toast.makeText(this, "DEBUG: getSmsPerms failed", Toast.LENGTH_SHORT).show();
        }
        sSMS.setChecked(smsPerms == 1);

        // Logic to let user go back to main screen
        bMainScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // verifies user intent one whether they want to return back to main screen
                Intent intent = new Intent(Settings.this, Weight_Info.class);
                intent.putExtra("key", username);
                startActivity(intent);
                finish();
            }
        });

        // Logic to save settings for goal weight, phone number, and SMS permissions
        bSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // --- grab inputs once ---
                String goalTxt  = eGoalWeight.getText().toString().trim();
                String phoneTxt = ePhoneNumber.getText().toString().trim();
                boolean smsOn   = sSMS.isChecked();

                // --- DEBUG so we know what’s happening ---
                Toast.makeText(Settings.this,
                        "DEBUG -> user=" + username + " goalTxt='" + goalTxt + "' phone='" + phoneTxt + "' sms=" + smsOn,
                        Toast.LENGTH_SHORT).show();

                // 1) GOAL: save + recompute deltas (only if a number was entered)
                if (!goalTxt.isEmpty()) {
                    try {
                        int goal = Integer.parseInt(goalTxt);

                        // save goal on user table
                        Database_User du = new Database_User(Settings.this);
                        boolean okGoal = du.updateGoalWeight(username, goal);

                        // recompute deltas for all rows for this user
                        Database_User_Weight wdb = new Database_User_Weight(Settings.this);
                        int rows = wdb.updateWeightDiff(username, goal);

                        Toast.makeText(
                                Settings.this,
                                (okGoal ? "Goal saved (" + goal + "). " : "Goal save FAILED. ") +
                                        "Recomputed " + rows + " row(s).",
                                Toast.LENGTH_LONG
                        ).show();

                    } catch (NumberFormatException nfe) {
                        Toast.makeText(Settings.this, "Invalid goal weight.", Toast.LENGTH_SHORT).show();
                    } catch (Exception ex) {
                        Toast.makeText(Settings.this, "Goal update error: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // optional: tell us we skipped the goal block
                    // Toast.makeText(Settings.this, "DEBUG: no goal provided.", Toast.LENGTH_SHORT).show();
                }

                // 2) PHONE (optional)
                if (!phoneTxt.isEmpty()) {
                    try {
                        Database_User du = new Database_User(Settings.this);
                        boolean ok = du.updatePhoneNumber(username, phoneTxt);
                        Toast.makeText(Settings.this, ok ? "Phone number updated." : "Phone update FAILED.", Toast.LENGTH_SHORT).show();
                    } catch (Exception ex) {
                        Toast.makeText(Settings.this, "Phone update error: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }

                // 3) SMS toggle
                try {
                    Database_User du = new Database_User(Settings.this);
                    boolean okSms = du.updateSmsPerms(username, smsOn ? 1 : 0);
                    if (smsOn) {
                        if (ContextCompat.checkSelfPermission(Settings.this, Manifest.permission.SEND_SMS)
                                != PackageManager.PERMISSION_GRANTED) {
                            requestSMSPermission();
                        }
                    }
                    Toast.makeText(Settings.this, okSms ? "SMS perms updated." : "SMS perms update FAILED.", Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {
                    Toast.makeText(Settings.this, "SMS perms error: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
                }

                // 4) Back to main (Weight_Info.onResume() will reload the list)
                Intent intent = new Intent(Settings.this, Weight_Info.class);
                intent.putExtra("key", username);
                startActivity(intent);
                finish();
            }
        });
    }

    // Source: SMSPermissions https://stackoverflow.com/questions/39738711/android-shouldshowrequestpermissionrationale-has-a-bug
    // Method for requesting SMS permissions
    private void requestSMSPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {

            // Alert Dialog if permissions is allowed
            new AlertDialog.Builder(this).setTitle("Permission needs to be set").setMessage("Permission needed for app to coomunciate with you").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    ActivityCompat.requestPermissions(Settings.this, new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
                }

                // Alert Dialog if user say no to allowing permissions
            }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }).create().show();
        }
        else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }
    // Source: onRequestPermissions https://stackoverflow.com/questions/32714787/android-m-permissions-onrequestpermissionsresult-not-being-called
    // Set permissions settings in database
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission allowed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();

            }
        }
    }
}